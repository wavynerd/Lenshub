<?php

/**
 * Class ProductFunctionsTest
 * @group product
 */
class FunctionsTemplatesTests extends WP_UnitTestCase {

	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}
}

