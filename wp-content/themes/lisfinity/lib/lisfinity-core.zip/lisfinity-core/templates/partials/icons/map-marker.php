<?php
/**
 * Partial Name: Icon | Star
 * Description: SVG icon used on a various places in the theme
 *
 * @author pebas
 * @package templates/icons
 * @version 1.0.0
 *
 * @var $icon_args
 */
?>
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
     y="0px"
     viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"
     class="<?php echo esc_attr( implode( ' ', $icon_args ) ); ?>">
<g>
    <path d="M50,1.8c-18.1,0-32.8,14.7-32.8,32.8c0,17.3,29.3,58.8,30.6,60.5l2.2,3.2l2.2-3.2c1.2-1.8,30.6-43.2,30.6-60.5
		C82.8,16.5,68.1,1.8,50,1.8z M50,88.7c-9.3-13.6-27.3-42.2-27.3-54.1C22.7,19.5,34.9,7.3,50,7.3s27.3,12.3,27.3,27.3
		C77.3,46.4,59.3,75.1,50,88.7z"/>
    <path d="M50,19c-7.9,0-14.3,6.4-14.3,14.3S42.1,47.6,50,47.6c7.9,0,14.3-6.4,14.3-14.3S57.9,19,50,19z M50,42.1
		c-4.9,0-8.8-4-8.8-8.8s4-8.8,8.8-8.8s8.8,4,8.8,8.8S54.9,42.1,50,42.1z"/>
</g>
</svg>
