<?php
/**
 * Partial Name: Icon | Star
 * Description: SVG icon used on a various places in the theme
 *
 * @author pebas
 * @package templates/icons
 * @version 1.0.0
 *
 * @var $icon_args
 */
?>
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
     y="0px"
     viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"
     class="<?php echo esc_attr( implode( ' ', $icon_args ) ); ?>"
>
<style type="text/css">
    .st0 {
        fill: none;
    }
</style>
    <g>
        <path class="st0" d="M50,50L50,50L50,50z"/>
    </g>
    <g>
        <path class="st0" d="M50,50L50,50L50,50z"/>
    </g>
    <g>
        <path d="M23.2,95.2c-0.8,0-1.5-0.2-2.2-0.7c-1.2-0.8-1.7-2.2-1.5-3.7l4.7-27.9L3.9,43.1c-1-1-1.4-2.5-0.9-3.8
		c0.4-1.4,1.6-2.3,3-2.6l28-4.3L46.6,6.9c0.6-1.3,1.9-2.1,3.4-2.1c1.4,0,2.7,0.8,3.4,2.1L66,32.4l28,4.2c1.4,0.2,2.6,1.2,3,2.6
		c0.4,1.4,0.1,2.8-0.9,3.8L75.8,62.8l4.7,27.9c0.2,1.4-0.3,2.8-1.5,3.7s-2.7,1-3.9,0.3L50,81.6L24.9,94.7
		C24.4,95,23.8,95.2,23.2,95.2z M10.3,41.6L30.1,61l-4.6,27.2L50,75.4l24.5,12.7l-4.6-27.3l19.8-19.4l-27.4-4.1L50,12.5L37.7,37.4
		L10.3,41.6z"/>
    </g>
    <g>
        <path class="st0" d="M50,50L50,50L50,50z"/>
    </g>
    <g>
        <path class="st0" d="M50,50L50,50L50,50z"/>
    </g>
    <g>
        <path class="st0" d="M50,50L50,50L50,50z"/>
    </g>
</svg>
