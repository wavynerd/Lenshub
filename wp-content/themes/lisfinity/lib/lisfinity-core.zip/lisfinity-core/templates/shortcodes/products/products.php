<?php
/**
 * Template Name: Shortcodes | Products Style Loader
 * Description: The file that is being used to display products and various product types
 *
 * @author pebas
 * @package templates/shortcodes
 * @version 1.0.0
 *
 * @var $args
 */

?>

<?php if ( lisfinity_show_listings_to_premium_only() ): ?>
	<?php $modal_type = lisfinity_get_option( 'site-fields-builder-premium-type' ) ?? 'member'; ?>
	<div class="p-40 bg-blue-100 border border-blue-200 rounded">
		<h5
			class="flex font-bold text-grey-900"><?php 'premium' === $modal_type ? _e( 'Listings available to premium users only', 'lisfinity-core' ) : _e( 'Listings available to members only', 'lisfinity-core' ); ?></h5>
		<div class="mt-10 text-grey-600">
			<?php if ( 'premium' === $modal_type ) : ?>
				<?php _e( 'The listings are available only for the premium users! But, do not worry, you can <strong>you can become a premium user anytime</strong> by clicking on the button below.', 'lisfinity-core' ); ?>
			<?php else: ?>
				<?php _e( 'The listings are available only for the site members! But, do not worry, you can <strong>you can become a member anytime</strong> by clicking on the button below.', 'lisfinity-core' ); ?>
			<?php endif; ?>
		</div>
		<div class="inline-block mt-20">
			<?php if ( is_user_logged_in() ) : ?>
				<a href="<?php echo esc_url( get_permalink( lisfinity_get_page_id( 'page-account' ) ) . '/premium-profile' ); ?>"
				   class="relative flex justify-center items-center py-12 px-24 h-44 bg-blue-700 hover:bg-blue-800 rounded font-bold text-base text-white"><?php 'premium' === $modal_type ? _e( 'Become a Premium', 'lisfinity-core' ) : _e( 'Become a Member', 'lisfinity-core' ); ?></a>
			<?php else: ?>
				<a href="<?php echo esc_url( get_permalink( lisfinity_get_page_id( 'page-login' ) ) ); ?>"
				   class="relative flex justify-center items-center py-12 px-24 h-44 bg-blue-700 hover:bg-blue-800 rounded font-bold text-base text-white"><?php 'premium' === $modal_type ? _e( 'Become a Premium', 'lisfinity-core' ) : _e( 'Become a Member', 'lisfinity-core' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
	<?php return; ?>
<?php endif; ?>

<div class="lisfinity-product-tabs">
	<?php if ( ! empty( $args['tab_titles'] ) && count( $args['tab_titles'] ) > 1 ): ?>
		<?php $tab_products_count = 0; ?>
		<div class="product-tabs inline-flex flex-wrap sm:mb-48 shadow-theme overflow-hidden">
			<?php foreach ( $args['tab_titles'] as $title ) : ?>
				<?php $slug = sanitize_title( $title ); ?>
				<div class="product-tabs--header w-full xs:w-auto">
					<button type="button"
							class="product-tab flex items-center sm:justify-center py-14 px-32 w-full h-full text-sm sm:text-base bg-white sm:bg-transparent <?php echo 0 === $tab_products_count ? esc_attr( 'active' ) : ''; ?>"
							data-tab="<?php echo esc_html( $slug ); ?>">
						<?php echo esc_html( $title ); ?>
					</button>
				</div>
				<?php $tab_products_count += 1; ?>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $args['tab_products'] ) ): ?>
		<?php $tab_products_count = 0; ?>
		<?php foreach ( $args['tab_products'] as $product ) : ?>
			<?php $args['options'] = $args['settings']['product_tabs'][ $tab_products_count ]; ?>
			<?php if ( lisfinity_is_elementor_preview() && 'yes' === ( $args['options']['visited'] ) && empty( get_user_meta( get_current_user_id(), 'recent-listings' ) ) ) : ?>
				<div class="flex mb-10 p-20 rounded bg-blue-100 border border-blue-300 text-blue-500 font-semibold">
					<?php esc_html_e( 'At the moment you haven\'t visited any of the listings and the latest listings will be shown to you. This message is only visible in the Elementor preview mode.', 'lisfinity-core' ); ?>
				</div>
			<?php endif; ?>
			<div
				class="product-tabs--content elementor-repeater-item-<?php echo $args['options']['_id']; ?> <?php echo esc_attr( "listing-style__{$args['settings']['style']}" ); ?> <?php echo 0 !== $tab_products_count ? esc_attr( 'hidden' ) : 'block'; ?>"
				data-content="<?php echo esc_html( sanitize_title( $args['tab_titles'][ $tab_products_count ] ) ); ?>">
				<?php $args['products'] = $product; ?>
				<?php include lisfinity_get_template_part( "product-style-{$args['settings']['style']}", 'shortcodes/products/product-styles', $args ); ?>
			</div>
			<?php $tab_products_count += 1; ?>
		<?php endforeach; ?>
	<?php endif; ?>
</div>
