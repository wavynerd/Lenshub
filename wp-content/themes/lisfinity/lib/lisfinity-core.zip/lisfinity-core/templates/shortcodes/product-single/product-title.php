<?php
/**
 * Template Name: Shortcodes | Product Title
 * Description: The file that is being used to display product title shortcode
 *
 * @author pebas
 * @package templates/shortcodes/single
 * @version 1.0.0
 *
 * @var $args
 */
?>
<div class="elementor-product-title"></div>
