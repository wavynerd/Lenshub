<?php

/**
 * Template Name: Elements Page
 * Description: Page template that is being used as the custom elementor post type elements
 *
 * @author pebas
 * @package templates/pages
 * @version 1.0.0
 */
?>

<div>My Elementor Elements</div>
